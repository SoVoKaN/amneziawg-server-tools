check_awg_client_exists() {
    if [ -f "${AWG_SERVER_TOOLS_PATH}/interfaces/${AWG_INTERFACE_NAME}/clients/${1}.data" ]; then
        return 0
    fi

    return 1
}

get_awg_interface_name_clients_menu() {
    printf "${BOLD_FS}Enter interface name to manage its clients.${DEFAULT_FS}\n"
    printf '%s' "Name: "

    handle_user_input

    echo ""

    if [ -z "$USER_INPUT" ]; then
        echo "Interface name can not be empty."
        exit 1
    fi

    if [ ${#USER_INPUT} -gt 15 ]; then
        echo "Interface name length must be < 16."
        exit 1
    fi

    if ! check_awg_interface_exists "$USER_INPUT"; then
        echo "Interface \"${USER_INPUT}\" does not exists."
        exit 1
    fi

    AWG_INTERFACE_NAME="$USER_INPUT"

    clean_lines "3"
}

awg_sync_clients() {
    ACTIVE_INTERFACES=$(awg show interfaces)
    ACTIVE_INTERFACES=" ${ACTIVE_INTERFACES} "

    if ! echo "$ACTIVE_INTERFACES" | grep " ${AWG_INTERFACE_NAME} " > /dev/null 2>&1; then
        return
    fi

    TEMP_FILE=$(mktemp)

    awg-quick strip "/etc/amnezia/amneziawg/${AWG_INTERFACE_NAME}.conf" > "$TEMP_FILE" 2>/dev/null

    awg syncconf "$AWG_INTERFACE_NAME" "$TEMP_FILE"

    rm "$TEMP_FILE"
}

load_client_data() {
    . "${AWG_SERVER_TOOLS_PATH}/interfaces/${AWG_INTERFACE_NAME}/clients/${AWG_CLIENT_NAME}.data"
}

clients_menu() {
    echo "----------------"
    printf "${BOLD_FS} Manage clients ${DEFAULT_FS}\n"
    echo "----------------"
    echo ""

    if select_awg_interface_submenu "get_awg_interface_name_clients_menu" "all"; then
        SUBMENU_RETURN_CODE="0"
    else
        SUBMENU_RETURN_CODE="$?"
    fi

    clean_lines "4"

    if [ "$SUBMENU_RETURN_CODE" = "1" ]; then
        return
    elif [ "$SUBMENU_RETURN_CODE" = "2" ]; then
        set_awg_server_tools_pager

        if [ -n "$AWG_SERVER_TOOLS_PAGER" ]; then
            printf "$SELECT_INTERFACE_SUBMENU_FAILURE_RETURN_MESSAGE" | "$AWG_SERVER_TOOLS_PAGER"
        else
            printf "\n${BOLD_FS}${SELECT_INTERFACE_SUBMENU_FAILURE_RETURN_MESSAGE}${DEFAULT_FS}\n\n"
        fi

        return
    fi

    load_interface_data

    while :; do
        print_dashes "$((19 + ${#AWG_INTERFACE_NAME}))"
        printf "${BOLD_FS} Manage clients [${AWG_INTERFACE_NAME}] ${DEFAULT_FS}\n"
        print_dashes "$((19 + ${#AWG_INTERFACE_NAME}))"
        echo ""
        echo "1) Enable client"
        echo "2) Disable client"
        echo "3) List clients"
        echo "4) Create client"
        echo "5) Delete client"
        echo "6) Rename client"
        echo "7) Show client QR"
        echo ""
        echo "0) Back"
        echo ""

        printf "Select option [0-7]: "

        handle_user_input

        clean_lines "15"

        case "$USER_INPUT" in
            "1")
                enable_awg_client
                ;;
            "2")
                disable_awg_client
                ;;
            "3")
                list_awg_clients
                ;;
            "4")
                create_awg_client
                exit 0
                ;;
            "5")
                delete_awg_client
                ;;
            "6")
                rename_client
                ;;
            "7")
                show_awg_client_qr
                ;;
            "0")
                break
                ;;
        esac
    done
}
